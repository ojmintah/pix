#!/usr/bin/env python3
"""
tf.launch.py  -- brings up the full A2 TF tree for navigation/localization.

Publishes:
  odom -> base_link                 (odom_tf_broadcaster, from /odommodestate)
  base_link -> camera_link
  base_link -> front_lidar_link
  base_link -> rear_lidar_link
  base_link -> central_lidar_link
  base_link -> legs                 (all from robot_state_publisher + URDF)

Still needed for full navigation:
  map -> odom                        (published later by your localizer:
                                      RTAB-Map / AMCL / etc.)

Usage:
  ros2 launch a2_tf tf.launch.py
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('a2_tf')
    urdf_path = os.path.join(pkg, 'urdf', 'a2.urdf')

    with open(urdf_path, 'r') as f:
        robot_description = f.read()

    return LaunchDescription([
        # base_link -> sensors + legs, from the URDF
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_description}],
        ),

        # supplies zero joint states so robot_state_publisher can compute the
        # (leg) frames. The SENSOR frames are fixed to base_link and do not
        # depend on this -- so zeros are fine for navigation. Replace with a
        # real joint-state bridge (from lowstate) only if you want the legs to
        # animate.
        Node(
            package='joint_state_publisher',
            executable='joint_state_publisher',
            name='joint_state_publisher',
            output='screen',
        ),

        # odom -> base_link, from the robot's odometry
        Node(
            package='a2_tf',
            executable='odom_tf_broadcaster',
            name='odom_tf_broadcaster',
            output='screen',
            parameters=[{
                'odom_topic': '/odommodestate',
                'odom_frame': 'odom',
                'base_frame': 'base_link',
                'publish_odom_msg': True,
            }],
        ),
    ])
