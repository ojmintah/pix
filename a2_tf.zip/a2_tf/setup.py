import os
from glob import glob
from setuptools import setup

package_name = 'a2_tf'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # install launch, urdf, rviz so get_package_share_directory finds them
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'rviz'), glob('rviz/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='A2 Developer',
    maintainer_email='dev@example.com',
    description='TF tree for the Unitree A2 (odom->base_link + URDF).',
    license='MIT',
    entry_points={
        'console_scripts': [
            'odom_tf_broadcaster = a2_tf.odom_tf_broadcaster:main',
        ],
    },
)
