#!/usr/bin/env python3
"""
odom_tf_broadcaster.py

Publishes the odom -> base_link TF for the Unitree A2, sourced from the robot's
state topic (unitree_go/msg/SportModeState on /odommodestate).

This is the one dynamic transform you must provide yourself. The rest of the
tree (base_link -> sensors/legs) comes from robot_state_publisher + the URDF,
and map -> odom comes from your localizer (RTAB-Map / AMCL) later.

IMPORTANT: Unitree stores the orientation quaternion in imu_state.quaternion as
[w, x, y, z]. ROS geometry_msgs/Quaternion is [x, y, z, w]. This node remaps the
order correctly -- getting this wrong makes the robot's heading garbage in RViz.

Also optionally publishes a nav_msgs/Odometry on /odom (handy for Nav2 / EKF).
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from unitree_go.msg import SportModeState
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster


class OdomTFBroadcaster(Node):
    def __init__(self):
        super().__init__('odom_tf_broadcaster')

        # --- parameters (override at launch if needed) ---
        self.declare_parameter('odom_topic', '/odommodestate')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('publish_odom_msg', True)   # also publish /odom

        odom_topic = self.get_parameter('odom_topic').value
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.publish_odom_msg = self.get_parameter('publish_odom_msg').value

        # Unitree state topics are commonly BEST_EFFORT. Match it so we actually
        # receive data (a RELIABLE subscription to a BEST_EFFORT publisher gets
        # nothing). If you see no data, this QoS is the first thing to check.
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )

        self.br = TransformBroadcaster(self)
        self.sub = self.create_subscription(
            SportModeState, odom_topic, self.cb, qos)

        if self.publish_odom_msg:
            self.odom_pub = self.create_publisher(Odometry, '/odom', 10)

        self.get_logger().info(
            f"odom_tf_broadcaster: {odom_topic} -> TF {self.odom_frame} -> {self.base_frame}")

    def cb(self, msg: SportModeState):
        now = self.get_clock().now().to_msg()

        # position: [x, y, z]
        px, py, pz = msg.position[0], msg.position[1], msg.position[2]

        # orientation: Unitree quaternion is [w, x, y, z]  -> ROS [x, y, z, w]
        qw = msg.imu_state.quaternion[0]
        qx = msg.imu_state.quaternion[1]
        qy = msg.imu_state.quaternion[2]
        qz = msg.imu_state.quaternion[3]

        # --- broadcast the TF: odom -> base_link ---
        t = TransformStamped()
        t.header.stamp = now
        t.header.frame_id = self.odom_frame
        t.child_frame_id = self.base_frame
        t.transform.translation.x = float(px)
        t.transform.translation.y = float(py)
        t.transform.translation.z = float(pz)
        t.transform.rotation.x = float(qx)
        t.transform.rotation.y = float(qy)
        t.transform.rotation.z = float(qz)
        t.transform.rotation.w = float(qw)
        self.br.sendTransform(t)

        # --- optionally publish a nav_msgs/Odometry too ---
        if self.publish_odom_msg:
            odom = Odometry()
            odom.header.stamp = now
            odom.header.frame_id = self.odom_frame
            odom.child_frame_id = self.base_frame
            odom.pose.pose.position.x = float(px)
            odom.pose.pose.position.y = float(py)
            odom.pose.pose.position.z = float(pz)
            odom.pose.pose.orientation.x = float(qx)
            odom.pose.pose.orientation.y = float(qy)
            odom.pose.pose.orientation.z = float(qz)
            odom.pose.pose.orientation.w = float(qw)
            # body-frame linear velocity + yaw rate
            odom.twist.twist.linear.x = float(msg.velocity[0])
            odom.twist.twist.linear.y = float(msg.velocity[1])
            odom.twist.twist.linear.z = float(msg.velocity[2])
            odom.twist.twist.angular.z = float(msg.yaw_speed)
            self.odom_pub.publish(odom)


def main():
    rclpy.init()
    node = OdomTFBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
